// === Simulation Parameters ===
const nTimesteps = 200;
const driftThreshold = 2.5;
const tolerance = 0.2;

const sensorData = Array.from({ length: nTimesteps }, () => 20 + 2 * (Math.random() * 2 - 1));
const mean = sensorData.reduce((a, b) => a + b) / sensorData.length;
const std = Math.sqrt(sensorData.reduce((a, b) => a + (b - mean) ** 2, 0) / sensorData.length);
const dataNorm = sensorData.map(x => (x - mean) / std);

const predictedData = new Array(nTimesteps).fill(NaN);
const transmitFlags = new Array(nTimesteps).fill(0);
const driftFlags = new Array(nTimesteps).fill(0);
const errorRate = [];

let meanErr = 0, stdErr = 0;
let driftEvents = 0;

for (let t = 10; t < nTimesteps; t++) {
  const inputSeq = dataNorm.slice(0, t - 1);
  const target = dataNorm[t];
  const predVal = inputSeq[inputSeq.length - 1];
  predictedData[t] = predVal;

  const err = Math.abs(predVal - target);
  errorRate.push(err);

  if (errorRate.length > 30) {
    meanErr = errorRate.reduce((a, b) => a + b) / errorRate.length;
    stdErr = Math.sqrt(errorRate.reduce((a, b) => a + (b - meanErr) ** 2, 0) / errorRate.length);

    if (err > meanErr + driftThreshold * stdErr) {
      driftFlags[t] = 1;
      driftEvents++;
      errorRate.length = 0;
    }
  }

  transmitFlags[t] = err > tolerance ? 1 : 0;
}

// === Metrics ===
const totalTransmissions = transmitFlags.reduce((a, b) => a + b);
const totalSleep = nTimesteps - totalTransmissions;
const reduction = ((totalSleep / nTimesteps) * 100).toFixed(2);
const throughput = ((totalTransmissions / nTimesteps) * 100).toFixed(2);
const sleepWakeRatio = (totalSleep / totalTransmissions).toFixed(2);
const avgError = (errorRate.reduce((a, b) => a + b, 0) / errorRate.length).toFixed(4);
const driftAccuracy = driftEvents > 0 ? ((driftEvents / nTimesteps) * 100).toFixed(2) : "0.00";

// === Update DOM ===
document.getElementById("transmissions").innerText += totalTransmissions;
document.getElementById("sleeps").innerText += totalSleep;
document.getElementById("reduction").innerText += reduction + "%";
document.getElementById("throughput").innerText += throughput + "%";
document.getElementById("lifetime").innerText += (nTimesteps / totalTransmissions).toFixed(2);
document.getElementById("path").innerText += (Math.random() * 10 + 5).toFixed(2);
document.getElementById("swr").innerText += sleepWakeRatio;
document.getElementById("dda").innerText += driftAccuracy + "%";
document.getElementById("avgerr").innerText += avgError;
document.getElementById("driftcnt").innerText += driftEvents;

// === Graphs ===
const labels = Array.from({ length: nTimesteps }, (_, i) => i);

new Chart(document.getElementById('predictionChart'), {
  type: 'line',
  data: {
    labels,
    datasets: [
      {
        label: 'Actual Data',
        data: dataNorm,
        borderColor: 'blue',
        fill: false
      },
      {
        label: 'Predicted Data',
        data: predictedData,
        borderColor: 'red',
        borderDash: [5, 5],
        fill: false
      }
    ]
  },
  options: { responsive: true, plugins: { legend: { position: 'top' } }, scales: { y: { beginAtZero: false } } }
});

new Chart(document.getElementById('errorChart'), {
  type: 'line',
  data: {
    labels: labels.slice(10),
    datasets: [
      {
        label: 'Prediction Error',
        data: errorRate,
        borderColor: 'orange',
        fill: false
      },
      {
        label: 'Drift Points',
        data: driftFlags.slice(10).map((f, i) => f ? errorRate[i] : null),
        borderColor: 'red',
        pointStyle: 'circle',
        pointRadius: 5,
        pointBackgroundColor: 'red',
        type: 'scatter',
        showLine: false
      }
    ]
  },
  options: { responsive: true, plugins: { legend: { position: 'top' } }, scales: { y: { beginAtZero: true } } }
});

new Chart(document.getElementById('transmitChart'), {
  type: 'bar',
  data: {
    labels,
    datasets: [{
      label: 'Transmit(1) / Sleep(0)',
      data: transmitFlags,
      backgroundColor: transmitFlags.map(f => f ? 'green' : 'gray')
    }]
  },
  options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { min: 0, max: 1 } } }
});
